﻿#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class Song
{
private:
    string songname;
    double BPM;
public:
    void setname(string input)
    {
        songname = input;
    }
    string getname()
    {
        return songname;
    }
    void setBPM(double input)
    {
        BPM = input;
    }
    double getBPM()
    {
        return BPM;
    }
    ~Song() {}
};

class Album
{
private:
    string albumname;
    int year;
    Song songs[30];
public:
    void setname(string input)
    {
        albumname = input;
    }
    string getname()
    {
        return albumname;
    }
    void setyear(int input)
    {
        year = input;
    }
    int getyear()
    {
        return year;
    }
    void setsong(Song input, int i)
    {
        songs[i] = input;
    }
    ~Album() {}
};

class Artist
{
private:
    string artistname;
    string genre;
    Album albums[15];
public:
    void setname(string input)
    {
        artistname = input;
    }
    string getname()
    {
        return artistname;
    }
    void setgenre(int input)
    {
        genre = input;
    }
    string getgenre()
    {
        return genre;
    }
    void setalbum(Album input, int i)
    {
        albums[i] = input;
    }
    ~Artist() {}
};

void displayseparated()
{
    ifstream database("database.txt");
    string tempstring;
    string result;
    string tempword;
    string separr[4];
    int sepint = 0;
    while (getline(database, tempstring))
    {
        result = tempstring;
        for (int i = 0; i < result.size(); i++)
        {
            if (result[i] != ';')
            {
                tempword += result[i];
            }
            else
            {
                separr[sepint] += tempword;
                tempword = "";
                sepint++;
            }
        }

        for (int o = 0; o < 4; o++)
        {
            cout << separr[o] << endl;
        }
        tempword = "";
        sepint = 0;
        fill_n(separr, 4, "");
        cout << endl << endl;
    }
    database.close();
}

/*Artist artistarr()
{
    Artist A;
    Artist *ptr;
    ptr =  &A;
    ifstream database("database.txt");
    string tempstring;
    string result;
    string tempword;
    string separr[4];
    int sepint = 0;
    while (getline(database, tempstring))
    {
        result = tempstring;
        for (int i = 0; i < result.size(); i++)
        {
            if (result[i] != ';')
            {
                tempword += result[i];
            }
            else
            {
                separr[sepint] += tempword;
                tempword = "";
                sepint++;
            }
        }
        ptr->setname(separr[0]);
        cout << ptr->getname();
        tempword = "";
        sepint = 0;
        fill_n(separr, 4, "");
        cout << endl << endl;
    }
    database.close();
}
*/

void searchbyname(string inputname)
{
    ifstream database("database.txt");
    string tempstring;
    string result;
    string tempword;
    string separr[4];
    int sepint = 0;
    while (getline(database, tempstring))
    {
        result = tempstring;
        for (int i = 0; i < result.size(); i++)
        {
            if (result[i] != ';')
            {
                tempword += result[i];
            }
            else
            {
                separr[sepint] += tempword;
                tempword = "";
                sepint++;
            }
        }
        if (separr[0] == inputname)
        {
            for (int o = 0; o < 4; o++)
            {
                cout << separr[o] << endl;
            }
            cout << endl << endl;
        }
        tempword = "";
        sepint = 0;
        fill_n(separr, 4, "");
    }
    database.close();
}

void searchbyalbum(string inputname)
{
    ifstream database("database.txt");
    string tempstring;
    string result;
    string tempword;
    string separr[4];
    int sepint = 0;
    while (getline(database, tempstring))
    {
        result = tempstring;
        for (int i = 0; i < result.size(); i++)
        {
            if (result[i] != ';')
            {
                tempword += result[i];
            }
            else
            {
                separr[sepint] += tempword;
                tempword = "";
                sepint++;
            }
        }
        if (separr[1] == inputname)
        {
            for (int o = 0; o < 4; o++)
            {
                cout << separr[o] << endl;
            }
            cout << endl << endl;
        }
        tempword = "";
        sepint = 0;
        fill_n(separr, 4, "");
    }
    database.close();
}

void searchbysong(string inputname)
{
    ifstream database("database.txt");
    string tempstring;
    string result;
    string tempword;
    string separr[4];
    int sepint = 0;
    while (getline(database, tempstring))
    {
        result = tempstring;
        for (int i = 0; i < result.size(); i++)
        {
            if (result[i] != ';')
            {
                tempword += result[i];
            }
            else
            {
                separr[sepint] += tempword;
                tempword = "";
                sepint++;
            }
        }
        if (separr[2] == inputname)
        {
            for (int o = 0; o < 4; o++)
            {
                cout << separr[o] << endl;
            }
            cout << endl << endl;
        }
        tempword = "";
        sepint = 0;
        fill_n(separr, 4, "");
    }
    database.close();
}

int main()
{
    string inputname;
    int choice = 0;
    cout << "Do you want to search by: 1 - artist, 2 - album, 3 - song." << endl << endl;
    cin >> choice;
    cin.ignore();
    displayseparated;

    if (choice == 1)
    {
        cout << "Enter artist name: " << endl;
        getline(cin, inputname);
        searchbyname(inputname);
    }
    else if (choice == 2)
    {   
        cout << "Enter album name: " << endl;
        getline(cin, inputname);
        searchbyalbum(inputname);
    }
    else if (choice == 3)
    {
        cout << "Enter song name: " << endl;
        getline(cin, inputname);
        searchbysong(inputname);
    }
    else
    {
        cout << "Wrong choice." << endl;
    }
}